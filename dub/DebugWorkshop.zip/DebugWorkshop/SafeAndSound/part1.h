#pragma once
char* string_copy(char* dest, unsigned int destsize, char* src);
void part1();